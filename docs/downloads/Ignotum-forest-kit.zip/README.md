# Ignotum forest kit

Copy art/, scenes/ and scripts/ into your Godot 4.7.2 project, keeping paths. Place scenes/objects/forest/ props in the 2D editor; choose Color Variant and optional Solid in the Inspector. Keep root scale 1. The editor catalog shows all 63 variants. Read docs/guides/FOREST_KIT_GUIDE.md for details. Shared scripts/interiors/ controls are required and included. The playable showroom is available only in the full Ignotum project.
