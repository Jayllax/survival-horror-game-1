# Ignotum interior asset kit

Copy the art/, scenes/ and scripts/ folders into the root of your Godot 4 project, keeping their paths. Open the project in Godot so it imports the PNGs and registers the scripts.

Drag scenes from scenes/objects/interiors/ into a level. Select an instance root and choose Color Variant: Warm, Sage or Slate. Artwork is already displayed at 2x native resolution. Lamps have real adjustable PointLight2D lights; stairs have authored walkable collision.

Read docs/guides/INTERIOR_KIT_GUIDE.md for origins, upper-floor construction, lamp controls and Pixilart editing. The included editor catalog is scenes/levels/interior_kit_catalog.tscn. The playable showroom is available in the full Ignotum repository on AI-changes.
