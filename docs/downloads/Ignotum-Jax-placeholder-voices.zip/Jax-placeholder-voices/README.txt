JAX - SYNTHETIC PLACEHOLDER VOICE

12 MP3 clips covering all current unique Jax lines, including branches and repeat dialogue.
Mono, 24 kHz, 96 kbps MP3. Source writing is preserved.
Use TRANSCRIPT.txt to match files to your DialogueLine Voice Audio fields.
Some lines occur in several branches; assign the same clip wherever its text repeats.

The puzzle number 1503 is spoken as "one, five, zero, three" for clarity.
The dialogue text itself is unchanged.
Playback levels are matched near -27 LUFS, with peak headroom.
Adjust each DialogueLine's Voice Volume Db in Godot to fit your final mix.

These are generated temporary performances, suitable for replacing with your actor later.
No player recordings, Godot scenes or GitHub files have been changed or assigned.

Generation: Kokoro-82M v1.0, stock voice am_michael (US English male), speed 1.0.
CPU ONNX int8 model; kokoro-onnx 0.6.1 engine.
Model: https://huggingface.co/hexgrad/Kokoro-82M (Apache License 2.0).
Engine: https://github.com/thewh1teagle/kokoro-onnx (MIT).
Model conversion: https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.1
The model's Apache license is included for provenance. No model or engine is bundled.
